// supabase/functions/matching-engine/index.ts
//
// Pure database-driven matching: profession match -> city match ->
// (area match if available) -> active + approved -> ranked by rating.
// No hardcoded professional/profession logic anywhere in here.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "احراز هویت لازم است" }, 401);

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user },
    } = await userClient.auth.getUser();
    if (!user) return json({ error: "احراز هویت نامعتبر" }, 401);

    const admin = createClient(supabaseUrl, serviceRoleKey);
    const { request_id } = await req.json();
    if (!request_id) return json({ error: "request_id لازم است" }, 400);

    const { data: request } = await admin
      .from("service_requests")
      .select("id, customer_id, profession_id, city, area, status")
      .eq("id", request_id)
      .single();

    if (!request || request.customer_id !== user.id) {
      return json({ error: "درخواست پیدا نشد" }, 404);
    }
    if (!request.profession_id) {
      return json({ error: "حرفهٔ موردنیاز هنوز مشخص نشده" }, 400);
    }

    // ---- Step 1: professionals who have this profession active ----
    const { data: matches } = await admin
      .from("professional_professions")
      .select("professional_id")
      .eq("profession_id", request.profession_id)
      .eq("is_active", true);

    const candidateIds = (matches ?? []).map((m) => m.professional_id);
    if (candidateIds.length === 0) {
      await admin.from("service_requests").update({ status: "MATCHING" }).eq("id", request_id);
      return json({ matched: [], message: "فعلاً متخصص فعالی برای این حرفه ثبت نشده" });
    }

    // ---- Step 2: filter by approved status + city (+ area bonus) ----
    let query = admin
      .from("professional_profiles")
      .select("profile_id, business_name, city:profiles!inner(city, area), rating_avg, rating_count, status")
      .in("profile_id", candidateIds)
      .eq("status", "approved");

    const { data: professionals, error: profError } = await query;
    if (profError) {
      console.error(profError);
      return json({ error: "خطا در جستجوی متخصص‌ها" }, 500);
    }

    let ranked = (professionals ?? []).filter((p: any) => {
      if (!request.city) return true; // no city filter set on request, allow all
      return p.city?.city === request.city;
    });

    // Area match is a ranking bonus, not a hard filter (per spec: city
    // required, area is a "nice to have" for now — distance comes later)
    ranked.sort((a: any, b: any) => {
      const aAreaMatch = request.area && a.city?.area === request.area ? 1 : 0;
      const bAreaMatch = request.area && b.city?.area === request.area ? 1 : 0;
      if (aAreaMatch !== bAreaMatch) return bAreaMatch - aAreaMatch;
      return (b.rating_avg ?? 0) - (a.rating_avg ?? 0);
    });

    if (ranked.length === 0) {
      await admin.from("service_requests").update({ status: "MATCHING" }).eq("id", request_id);
      return json({ matched: [], message: "فعلاً متخصص تأییدشده‌ای در شهر شما برای این حرفه پیدا نشد" });
    }

    // ---- Step 3: create request_matches + notifications ----
    const matchRows = ranked.map((p: any) => ({
      request_id,
      professional_id: p.profile_id,
      status: "sent",
    }));

    const { error: insertError } = await admin
      .from("request_matches")
      .upsert(matchRows, { onConflict: "request_id,professional_id", ignoreDuplicates: true });

    if (insertError) {
      console.error(insertError);
      return json({ error: "خطا در ثبت تطبیق" }, 500);
    }

    const notifications = ranked.map((p: any) => ({
      user_id: p.profile_id,
      title: "درخواست جدید",
      body: "یک درخواست تعمیر جدید در حرفهٔ شما ثبت شد",
      type: "new_request",
      related_request_id: request_id,
    }));
    await admin.from("notifications").insert(notifications);

    await admin.from("service_requests").update({ status: "SENT" }).eq("id", request_id);

    return json({
      matched: ranked.map((p: any) => ({ id: p.profile_id, name: p.business_name })),
      count: ranked.length,
    });
  } catch (err) {
    console.error("matching-engine error:", err);
    return json({ error: "خطای غیرمنتظره سرور" }, 500);
  }
});
