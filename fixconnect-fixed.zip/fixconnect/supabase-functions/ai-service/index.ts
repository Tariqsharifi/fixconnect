// supabase/functions/ai-service/index.ts
//
// AIService: takes a service_request_id, gathers its media + text,
// runs analysis through swappable AI providers, saves a structured
// ai_analyses row, updates the request, and logs usage.
//
// Frontend never talks to Gemini/Groq directly — only to this function.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

interface DiagnosisResult {
  device_type: string | null;
  brand: string | null;
  model: string | null;
  symptoms: string | null;
  possible_problems: string[];
  required_profession_slug: string | null;
  confidence: "low" | "medium" | "high";
  safety_warning: string | null;
  customer_answer: string;
}

const SYSTEM_PROMPT = `
تو یک دستیار عیب‌یاب لوازم هستی. بر اساس عکس/متن/صدای مشتری، این JSON رو برگردون:
{
  "device_type": "نوع وسیله یا null",
  "brand": "برند در صورت تشخیص یا null",
  "model": "مدل در صورت تشخیص یا null",
  "symptoms": "خلاصه علائم به فارسی",
  "possible_problems": ["مشکل احتمالی ۱", "مشکل احتمالی ۲"],
  "required_profession_slug": "یک اسلاگ کوتاه انگلیسی مثل fridge-repair یا null",
  "confidence": "low" | "medium" | "high",
  "safety_warning": "هشدار ایمنی در صورت نیاز یا null",
  "customer_answer": "یک پاسخ کوتاه و قابل فهم فارسی برای نمایش به مشتری"
}
هرگز تشخیص قطعی و خطرناک نده. اگر نیاز به باز کردن دستگاه، برق، گاز یا فشار داره، در safety_warning صراحتاً بگو باید به متخصص مراجعه شود.
فقط همین JSON رو برگردون، بدون هیچ متن اضافه.
`.trim();

class GeminiProvider {
  constructor(private apiKey: string) {}

  async analyzeImageAndText(imageBase64: string | null, mimeType: string, text: string): Promise<DiagnosisResult> {
    const parts: any[] = [{ text: `${SYSTEM_PROMPT}\n\nتوضیح مشتری: ${text || "(بدون متن)"}` }];
    if (imageBase64) {
      parts.push({ inline_data: { mime_type: mimeType, data: imageBase64 } });
    }

    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-3.1-flash-lite:generateContent?key=${this.apiKey}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts }],
          generationConfig: { responseMimeType: "application/json" },
        }),
      }
    );

    if (!res.ok) throw new Error(`Gemini error: ${res.status}`);
    const data = await res.json();
    const rawText = data?.candidates?.[0]?.content?.parts?.[0]?.text;
    return parseDiagnosis(rawText);
  }
}

class GroqProvider {
  constructor(private apiKey: string) {}

  async transcribeAudio(audioBase64: string, mimeType: string): Promise<string> {
    const bytes = Uint8Array.from(atob(audioBase64), (c) => c.charCodeAt(0));
    const form = new FormData();
    form.append("file", new Blob([bytes], { type: mimeType }), "audio.webm");
    form.append("model", "whisper-large-v3-turbo");
    form.append("language", "fa");

    const res = await fetch("https://api.groq.com/openai/v1/audio/transcriptions", {
      method: "POST",
      headers: { Authorization: `Bearer ${this.apiKey}` },
      body: form,
    });

    if (!res.ok) throw new Error(`Groq error: ${res.status}`);
    const data = await res.json();
    return data.text ?? "";
  }
}

function parseDiagnosis(rawText: string | undefined): DiagnosisResult {
  const fallback: DiagnosisResult = {
    device_type: null,
    brand: null,
    model: null,
    symptoms: null,
    possible_problems: [],
    required_profession_slug: null,
    confidence: "low",
    safety_warning: null,
    customer_answer: "نتوانستیم مشکل را با اطمینان تشخیص دهیم. لطفاً نوع وسیله را دستی انتخاب کنید.",
  };
  if (!rawText) return fallback;
  try {
    const cleaned = rawText.replace(/```json|```/g, "").trim();
    const parsed = JSON.parse(cleaned);
    return { ...fallback, ...parsed };
  } catch {
    return fallback;
  }
}

class AIService {
  private gemini: GeminiProvider;
  private groq: GroqProvider;

  constructor(geminiKey: string, groqKey: string) {
    this.gemini = new GeminiProvider(geminiKey);
    this.groq = new GroqProvider(groqKey);
  }

  async analyze(text: string, imageBase64: string | null, imageMime: string, audioBase64: string | null, audioMime: string): Promise<{ result: DiagnosisResult; providerUsed: string }> {
    let fullText = text || "";

    if (audioBase64) {
      const transcript = await this.groq.transcribeAudio(audioBase64, audioMime);
      fullText = [fullText, transcript].filter(Boolean).join(" — ");
    }

    const result = await this.gemini.analyzeImageAndText(imageBase64, imageMime, fullText);
    return { result, providerUsed: "gemini" };
  }
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: corsHeaders });

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const geminiKey = Deno.env.get("GEMINI_API_KEY");
  const groqKey = Deno.env.get("GROQ_API_KEY");

  try {
    if (!geminiKey || !groqKey) {
      return json({ error: "سرویس تشخیص هوشمند فعلاً در دسترس نیست" }, 500);
    }

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) return json({ error: "احراز هویت لازم است" }, 401);

    const userClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
      global: { headers: { Authorization: authHeader } },
    });
    const {
      data: { user },
    } = await userClient.auth.getUser();
    if (!user) return json({ error: "احراز هویت نامعتبر" }, 401);

    const admin = createClient(supabaseUrl, serviceRoleKey);
    const { request_id, text, image_base64, image_mime, audio_base64, audio_mime } = await req.json();

    if (!request_id) return json({ error: "request_id لازم است" }, 400);

    const { data: request } = await admin
      .from("service_requests")
      .select("id, customer_id")
      .eq("id", request_id)
      .single();

    if (!request || request.customer_id !== user.id) {
      return json({ error: "درخواست پیدا نشد" }, 404);
    }

    await admin.from("service_requests").update({ status: "ANALYZING" }).eq("id", request_id);

    let status: "success" | "failed" = "success";
    let result: DiagnosisResult;

    try {
      const ai = new AIService(geminiKey, groqKey);
      const outcome = await ai.analyze(
        text ?? "",
        image_base64 ?? null,
        image_mime ?? "image/jpeg",
        audio_base64 ?? null,
        audio_mime ?? "audio/webm"
      );
      result = outcome.result;
    } catch (err) {
      console.error("AI analysis failed:", err);
      status = "failed";
      result = {
        device_type: null, brand: null, model: null, symptoms: null,
        possible_problems: [], required_profession_slug: null,
        confidence: "low", safety_warning: null,
        customer_answer: "خطا در تحلیل هوشمند رخ داد. لطفاً نوع وسیله را دستی انتخاب کنید.",
      };
    }

    await admin.from("ai_usage").insert({
      user_id: user.id,
      provider: "gemini",
      type: image_base64 ? "image" : audio_base64 ? "audio" : "text",
      input_size: (text?.length ?? 0) + (image_base64?.length ?? 0) + (audio_base64?.length ?? 0),
      status,
    });

    // FIX: the previous code used .ilike(...).maybeSingle() for both
    // lookups. maybeSingle() errors out (not throws — just returns an
    // error + null data) whenever more than one row matches, which is
    // easy to hit here: multiple devices can share overlapping names
    // (e.g. "یخچال" ilike-matches both "یخچال" and "یخچال فریزر"), and
    // multiple professions could plausibly share a slug prefix too.
    // Because this block sits outside the try/catch around the AI
    // call, that error was swallowed silently — profession_id/device_id
    // just silently stayed null with no log, no error surfaced to the
    // customer, nothing. With more professions/devices (the whole
    // point of this being a generic multi-profession marketplace) this
    // gets more likely, not less. Fetch a small list instead, prefer
    // an exact case-insensitive match, and wrap it in try/catch so a
    // lookup failure can't silently swallow the rest of the analysis.
    let professionId: string | null = null;
    let deviceId: string | null = null;
    try {
      if (result.required_profession_slug) {
        const { data: profession, error: profErr } = await admin
          .from("professions")
          .select("id")
          .eq("slug", result.required_profession_slug)
          .limit(1)
          .maybeSingle();
        if (profErr) console.error("profession lookup error:", profErr);
        professionId = profession?.id ?? null;
      }
      if (result.device_type) {
        const { data: deviceRows, error: devErr } = await admin
          .from("devices")
          .select("id, profession_id, name")
          .eq("is_active", true)
          .ilike("name", `%${result.device_type}%`)
          .limit(5);
        if (devErr) {
          console.error("device lookup error:", devErr);
        } else if (deviceRows && deviceRows.length > 0) {
          const exact = deviceRows.find(
            (d) => d.name.toLowerCase() === result.device_type!.toLowerCase()
          );
          const chosen = exact ?? deviceRows[0];
          deviceId = chosen.id;
          if (!professionId) professionId = chosen.profession_id;
        }
      }
    } catch (lookupErr) {
      console.error("device/profession resolution failed:", lookupErr);
    }

    const { data: analysis } = await admin
      .from("ai_analyses")
      .insert({
        request_id,
        provider: "gemini",
        raw_response: result,
        device_type: result.device_type,
        device_id: deviceId,
        brand: result.brand,
        model: result.model,
        symptoms: result.symptoms,
        possible_problems: result.possible_problems,
        required_profession_id: professionId,
        confidence: result.confidence,
        safety_warning: result.safety_warning,
        customer_answer: result.customer_answer,
      })
      .select()
      .single();

    await admin
      .from("service_requests")
      .update({
        ai_analysis_id: analysis?.id,
        device_id: deviceId,
        profession_id: professionId,
        brand: result.brand,
        model: result.model,
        symptoms: result.symptoms,
        possible_problems: result.possible_problems,
        safety_warning: result.safety_warning,
        status: "NEW",
      })
      .eq("id", request_id);

    return json({ analysis: result, needs_manual_selection: result.confidence === "low" || !professionId });
  } catch (err) {
    console.error("ai-service error:", err);
    return json({ error: "خطای غیرمنتظره سرور" }, 500);
  }
});
