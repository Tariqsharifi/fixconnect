// supabase/functions/telegram-auth/index.ts
//
// Verifies a Telegram Login Widget payload, creates or updates the
// matching profile (default role: customer), and returns a Supabase
// session (access_token + refresh_token) for the frontend to apply.

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

// ---- helpers: hex encoding ----
function toHex(buf: ArrayBuffer): string {
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, "0"))
    .join("");
}

// ---- Telegram Login Widget verification ----
// https://core.telegram.org/widgets/login#checking-authorization
async function verifyTelegramAuth(
  data: Record<string, string | number>,
  botToken: string
): Promise<boolean> {
  const { hash, ...rest } = data as Record<string, string>;
  if (!hash) return false;

  const dataCheckString = Object.keys(rest)
    .sort()
    .map((key) => `${key}=${rest[key]}`)
    .join("\n");

  const encoder = new TextEncoder();
  const secretKey = await crypto.subtle.digest("SHA-256", encoder.encode(botToken));

  const hmacKey = await crypto.subtle.importKey(
    "raw",
    secretKey,
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );

  const signature = await crypto.subtle.sign(
    "HMAC",
    hmacKey,
    encoder.encode(dataCheckString)
  );

  const computedHash = toHex(signature);
  return computedHash === hash;
}

// Deterministic password derived from bot token + telegram id.
// Never sent to the client, never stored in plaintext — just used
// internally so we can sign the same user in every time via
// signInWithPassword without keeping a real password anywhere.
async function derivePassword(botToken: string, telegramId: number): Promise<string> {
  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    "raw",
    encoder.encode(botToken),
    { name: "HMAC", hash: "SHA-256" },
    false,
    ["sign"]
  );
  const sig = await crypto.subtle.sign(
    "HMAC",
    keyMaterial,
    encoder.encode(`fixconnect_tg_${telegramId}`)
  );
  return toHex(sig);
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    if (req.method !== "POST") {
      return json({ error: "Method not allowed" }, 405);
    }

    const botToken = Deno.env.get("TELEGRAM_BOT_TOKEN");
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    if (!botToken) {
      return json({ error: "Server misconfigured: missing bot token" }, 500);
    }

    const payload = await req.json();

    // Required fields from Telegram Login Widget
    const { id, first_name, last_name, username, photo_url, auth_date, hash } = payload;
    if (!id || !auth_date || !hash) {
      return json({ error: "درخواست نامعتبر" }, 400);
    }

    const isValid = await verifyTelegramAuth(payload, botToken);
    if (!isValid) {
      return json({ error: "امکان تأیید اطلاعات تلگرام وجود ندارد" }, 401);
    }

    // Reject stale login attempts (older than 24h)
    const authAge = Math.floor(Date.now() / 1000) - Number(auth_date);
    if (authAge > 86400) {
      return json({ error: "این ورود منقضی شده، دوباره تلاش کن" }, 401);
    }

    const admin = createClient(supabaseUrl, serviceRoleKey);
    const telegramId = Number(id);
    const fullName = [first_name, last_name].filter(Boolean).join(" ") || null;
    const password = await derivePassword(botToken, telegramId);
    const syntheticEmail = `tg_${telegramId}@fixconnect.internal`;

    // Does a profile with this telegram_id already exist?
    const { data: existingProfile } = await admin
      .from("profiles")
      .select("id")
      .eq("telegram_id", telegramId)
      .maybeSingle();

    let userId: string;

    if (existingProfile) {
      userId = existingProfile.id;

      // Keep telegram_username / photo fresh, in case they changed
      await admin
        .from("profiles")
        .update({
          telegram_username: username ?? null,
          telegram_photo_url: photo_url ?? null,
          full_name: fullName,
        })
        .eq("id", userId);
    } else {
      // Brand new user: create their auth account first
      const { data: createdUser, error: createError } = await admin.auth.admin.createUser({
        email: syntheticEmail,
        password,
        email_confirm: true,
        user_metadata: { telegram_id: telegramId, telegram_username: username ?? null },
      });

      if (createError || !createdUser?.user) {
        return json({ error: "خطا در ساخت حساب کاربری" }, 500);
      }

      userId = createdUser.user.id;

      const { error: profileError } = await admin.from("profiles").insert({
        id: userId,
        role: "customer",
        full_name: fullName,
        telegram_id: telegramId,
        telegram_username: username ?? null,
        telegram_photo_url: photo_url ?? null,
      });

      if (profileError) {
        return json({ error: "خطا در ساخت پروفایل" }, 500);
      }

      await admin.from("customer_profiles").insert({ profile_id: userId });
    }

    // Sign in as this user to obtain a real session for the frontend
    const anon = createClient(supabaseUrl, anonKey);
    const { data: signInData, error: signInError } = await anon.auth.signInWithPassword({
      email: syntheticEmail,
      password,
    });

    if (signInError || !signInData.session) {
      return json({ error: "خطا در ورود" }, 500);
    }

    const { data: profile } = await admin
      .from("profiles")
      .select("id, role, full_name, phone, city, area, is_blocked")
      .eq("id", userId)
      .single();

    if (profile?.is_blocked) {
      return json({ error: "حساب شما مسدود شده است" }, 403);
    }

    return json({
      session: {
        access_token: signInData.session.access_token,
        refresh_token: signInData.session.refresh_token,
      },
      profile,
    });
  } catch (err) {
    console.error("telegram-auth error:", err);
    return json({ error: "خطای غیرمنتظره سرور" }, 500);
  }
});
