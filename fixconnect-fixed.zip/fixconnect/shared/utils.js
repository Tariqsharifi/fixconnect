// shared/utils.js
//
// FIX (security): several pages were inserting user-supplied strings
// (chat messages, request symptoms, business names, admin fields...)
// directly into innerHTML with no escaping — a classic stored-XSS
// hole. Every page that builds HTML from DB content should wrap each
// interpolated value with esc() before putting it in a template
// literal that gets assigned to innerHTML.

export function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (c) => ({
    "&": "&amp;",
    "<": "&lt;",
    ">": "&gt;",
    '"': "&quot;",
    "'": "&#39;",
  }[c]));
}
